export const novosibirskPharmacies = [
  {
    id: 1,
    name: 'Аптека 36.6',
    address: 'ул. Ленина, 3',
    coordinates: [55.030204, 82.920430],
    workingHours: '08:00-22:00'
  },
  {
    id: 2,
    name: 'Аптека 36.6',
    address: 'Красный проспект, 25',
    coordinates: [55.041520, 82.934800],
    workingHours: '08:00-22:00'
  },
  {
    id: 3,
    name: 'Аптека 36.6',
    address: 'ул. Гоголя, 15',
    coordinates: [55.041800, 82.920900],
    workingHours: '08:00-22:00'
  },
  {
    id: 4,
    name: 'Горздрав',
    address: 'Красный проспект, 50',
    coordinates: [55.044900, 82.936900],
    workingHours: '08:00-21:00'
  },
  {
    id: 5,
    name: 'Горздрав',
    address: 'ул. Советская, 64',
    coordinates: [55.033900, 82.899800],
    workingHours: '08:00-21:00'
  },
  {
    id: 6,
    name: 'Ригла',
    address: 'ул. Каменская, 32',
    coordinates: [55.041200, 82.920100],
    workingHours: '08:00-22:00'
  },
  {
    id: 7,
    name: 'Аптека 36.6',
    address: 'ул. Фрунзе, 88',
    coordinates: [55.026800, 82.936200],
    workingHours: '08:00-22:00'
  },
  {
    id: 8,
    name: 'Горздрав',
    address: 'ул. Добролюбова, 2',
    coordinates: [55.042700, 82.915900],
    workingHours: '08:00-21:00'
  },
  {
    id: 9,
    name: 'Ригла',
    address: 'ул. Восход, 15',
    coordinates: [55.026400, 82.920700],
    workingHours: '08:00-22:00'
  },
  {
    id: 10,
    name: 'Горздрав',
    address: 'ул. Титова, 12',
    coordinates: [55.019800, 82.950900],
    workingHours: '08:00-21:00'
  }
]; 